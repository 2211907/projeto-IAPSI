'use strict'

var coinData;  //variáveis utilizadas
var Fav = [];
var FavI = 0;
var FavVisvel = 0;
var altData;
var i;
var x;
var y;
var color;
var oPreco = [];
var auxiliar = [];
var index;
var verdade;
var inverter = [6];
var Home = document.getElementById("pagina1");
var Detalhes = document.getElementById("paginaDetalhes")
var DetailsI

let tabelafav = document.getElementById("tabelafav")
let tabela = document.getElementById("tabela")


inverter[0] = 0; //Nome
inverter[1] = 0; //Preço
inverter[2] = 0; //Max 24h
inverter[3] = 0; //Min 24h
inverter[4] = 0; //24h %
inverter[5] = 0; //Valor de mercado

$(document).ready(function(){
	ReadAPIData();
	
});

function CorInicial(){  //iniciar em dark mode

	var i
    var x
    var y
    var z
    var t
    var header = document.getElementById("Header") //chamar elementos html através do seu id
    var favoritosTxt = document.getElementById("btnfavoritos")
    var content = document.getElementById("content")
    var search = document.getElementById("search")
    var vline = document.getElementById("Vline")
    var selectedlang = document.getElementById("selectedLang")
    var tdcontent = document.getElementsByClassName("tdcontent")
	var logoimg = document.getElementById("logoimg")
	var lightmode = document.getElementById("lightMode")
	x=1
        y=0
        header.setAttribute("style", "background-color: #1a1c1d") //atribuir valores de estilo aos elementos html
        favoritosTxt.setAttribute("style", "color:white;")
        content.setAttribute("style","background-color: #1a1c1d")
        search.setAttribute("style","background: #1a1c1d; color: #ffffff")
        vline.setAttribute("style", "background-color: white")
        selectedlang.setAttribute("style", "color: white;")
		logoimg.src = "white logo.png"
		lightmode.setAttribute("style", "color: #FAFAFA")
        for(i=0; i<tdcontent.length; i++) //percorrer todos os elementos
        {
            
            tdcontent[i].style.color = "#FAFAFA"
            tdcontent[i].style.backgroundColor = "#1a1c1d"
            tdcontent[i].style.boxShadow = "1px 3px #070808"
			tdcontent[i].style.justifyContent = "space-bettwen"
			tdcontent[i].style.lineHeight = "2"
            if(x == 7){
                
                x=1
                y++
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#111213"
                tdcontent[i].style.boxShadow = "1px 3px #000000"
                
            }
            x++
            
            
        }

}

function criarLinha(coinData){ //criar uma linha para a tabela top 100

	
	const indexTd = document.createElement("td") //criação de elementos html
	indexTd.classList.add("indextd")
    let linha = document.createElement("tr")
	let tdId = document.body.appendChild(indexTd)
    let tdName = document.createElement("td")
	let nameImg = document.createElement("img")
	let nameFav = document.createElement("button")
	let namefavImg = document.createElement("i")
    let tdPrice = document.createElement("td")
	let tdMax24 = document.createElement("td")
	let tdMin24 = document.createElement("td")
	let tdper24 = document.createElement("td")
	let tdMrktCap = document.createElement("td")

	nameFav.addEventListener('click', (event) =>{ //atribuição aos favoritos
		Fav[FavI] = coinData;
		FavI++
		nameFav.setAttribute("style","display:none");
	})
	linha.id = "linha" //atrivuição de ids
	nameImg.id = "tableImg"
	nameFav.id = "favButton"
	namefavImg.className = "fas fa-star"
	tdName.className = "tdcontent"
	tdPrice.className = "tdcontent"
	tdMax24.className = "tdcontent"
	tdMin24.className = "tdcontent"
	tdper24.className = "tdcontent"
	tdMrktCap.className = "tdcontent"

	tdId.innerHTML = i  //atribuição de valores
	nameImg.src = coinData.image
    tdName.innerHTML = coinData.name
    tdPrice.innerHTML = coinData.current_price + "$"
	tdMax24.innerHTML = coinData.high_24h + "$"
	tdMin24.innerHTML = coinData.low_24h + "$"
	tdper24.innerHTML = coinData.price_change_percentage_24h + "%"
	tdMrktCap.innerHTML = coinData.market_cap + "$"
	
    linha.appendChild(tdId); //atribuição de posição através de quem são subelementos
	tdName.appendChild(nameImg);
	tdName.appendChild(nameFav);
	nameFav.appendChild(namefavImg);
    linha.appendChild(tdName);
    linha.appendChild(tdPrice);
	linha.appendChild(tdMax24);
	linha.appendChild(tdMin24);
	linha.appendChild(tdper24);
	linha.appendChild(tdMrktCap);

    return linha;

}

function criarFavLinha(Fav){ //criar uma linha para a tabela de favoritos

	
	const indexTd = document.createElement("td") //criação de elementos html
	indexTd.classList.add("indextd")
    let linha = document.createElement("tr")
	let tdId = document.body.appendChild(indexTd)
    let tdName = document.createElement("td")
	let nameImg = document.createElement("img")
	let nameFav = document.createElement("button")
	let namefavImg = document.createElement("i")
    let tdPrice = document.createElement("td")
	let tdMax24 = document.createElement("td")
	let tdMin24 = document.createElement("td")
	let tdper24 = document.createElement("td")
	let tdMrktCap = document.createElement("td")

	linha.id = "linhafav" //atribuição de ids
	nameImg.id = "tableImg"
	nameFav.id = "favButton"
	namefavImg.className = "fas fa-star"
	tdName.className = "tdcontent"
	tdPrice.className = "tdcontent"
	tdMax24.className = "tdcontent"
	tdMin24.className = "tdcontent"
	tdper24.className = "tdcontent"
	tdMrktCap.className = "tdcontent"

	tdId.innerHTML = i  //atribuição de valores
	nameImg.src = Fav.image
    tdName.innerHTML = Fav.name
    tdPrice.innerHTML = Fav.current_price + "$"
	tdMax24.innerHTML = Fav.high_24h + "$"
	tdMin24.innerHTML = Fav.low_24h + "$"
	tdper24.innerHTML = Fav.price_change_percentage_24h + "%"
	tdMrktCap.innerHTML = Fav.market_cap + "$"
	

    linha.appendChild(tdId);  //atribuição de posição através de quem são subelementos
	tdName.appendChild(nameImg);
	tdName.appendChild(nameFav);
	nameFav.appendChild(namefavImg);
    linha.appendChild(tdName);
    linha.appendChild(tdPrice);
	linha.appendChild(tdMax24);
	linha.appendChild(tdMin24);
	linha.appendChild(tdper24);
	linha.appendChild(tdMrktCap);

    return linha;

}

function seeFav(){  //abrir a janela de favoritos
	
	i = 1;
tabelaFav.setAttribute("style","display: block")
tabela.setAttribute("style","display: none")

    $("* #linhafav").remove(); //remover linhas para atualizar
    Fav.forEach(element => { //criar uma linha para cada elementos dos favoritos
		
        let linha = criarFavLinha(element)
        tabelaFav.appendChild(linha)
        i = i+1;
			
    });
	

}

function buildCoinTable(res){  //criação da tabela 
    i = 1;
	coinData=res;
	auxiliar = coinData;

    coinData.forEach(element => { //criar uma linha para cada elementos da api
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		
    });
	CorInicial() 
	
}

function Onome(){ //ordenar por nome

	if(inverter[0] == 0) //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.name > b.name){
				return 1;
			}
			if (a.name < b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.name < b.name){
				return 1;
			}
			if (a.name > b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 0;
	}
	
    
	i=1;
    coinData.forEach(element => { //criar uma linha para cada elementos da api
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}



function Oprice(){ //ordenar por preço
	if(inverter[1] == 0) //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.current_price > b.current_price){
				return 1;
			}
			if (a.current_price < b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.current_price < b.current_price){
				return 1;
			}
			if (a.current_price > b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 0;
	}

	i=1;
    coinData.forEach(element => { //criar uma linha para cada elementos da api
		$("#linha").remove();
		$("#linhaFav").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omax24(){ //ordenar por máximo em 24h
	if(inverter[2] == 0) //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.high_24h > b.high_24h){
				return 1;
			}
			if (a.high_24h < b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.high_24h < b.high_24h){
				return 1;
			}
			if (a.high_24h > b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 0;
	}

	i=1;
    coinData.forEach(element => { //criar uma linha para cada elementos da api
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}
 
function Omin24(){ //ordenar por minimo em 24h
	if(inverter[3] == 0)  //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.low_24h > b.low_24h){
				return 1;
			}
			if (a.low_24h < b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.low_24h < b.low_24h){
				return 1;
			}
			if (a.low_24h > b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 0;
	}

	i=1;
    coinData.forEach(element => {  //criar uma linha para cada elementos da api
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		
		var btnCP = coinData[0].current_price
    }); 
}

function Oper24(){ //ordenar por percentagem em 24h
	if(inverter[4] == 0) //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 0;
	}

	i=1;
    coinData.forEach(element => { //criar uma linha para cada elementos da api
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omrktcap(){ //ordenar por valor de mercado
	
    if(inverter[5] == 0)  //inversão da ordem
	{
		coinData.sort(function (a, b) {
			if (a.market_cap > b.market_cap){
				return 1;
			}
			if (a.market_cap < b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.market_cap < b.market_cap){
				return 1;
			}
			if (a.market_cap > b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 0;
	}
    
	i=1;
    coinData.forEach(element => { //criar uma linha para cada elementos da api
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function ReadAPIData(){ //chamar APi e transformar em objeto JSON
	$.ajax({
		url: 'https://api.coingecko.com/api/v3/coins/markets?per_page=100&vs_currency=usd',
		headers:{
			'Content-Type': 'application/json',
		},
		method: 'GET',
		dataType: 'json',
		data: '',
		success: function(res){
			buildCoinTable(res);
		}
	});
}

function OpenDetails(){ //abrir janela de detalhes
	var z
	var x = document.getElementById("searchTxt").value; //chamar valor introduzido na pesquisa

	for(z=0 ; z<100; z++) //percorres todos os nomes da API
	{
		if (x === coinData[z].name){ // se o valor introduzido for igual ao nome da posição onde está

			console.log(coinData[z].name)
		    DetailsI = z;
			Home.setAttribute("style","display: none")
			paginaDetalhes()
			
		}
		
	}

	
	
}

function homeReturn(){ //retornar à pagina inicial
	Home.setAttribute("style","display: block") //esconder elementos e mostrar outros
	Detalhes.setAttribute("style","display: none")
	tabelaFav.setAttribute("style","display: none")
    tabela.setAttribute("style","display: block")
	FavVisvel = 0;
}

function paginaDetalhes(){	//construção da janela de detalhes
	Detalhes.setAttribute("style","display: block")
	location.href = "#";

	$("#Cranking").remove(); //remover todos os valores para atualizar
	$("#preçoAtual").remove();
	$("#Cnome").remove();
	$("#Cimagem").remove();
	$("#CpreçoAtual").remove();
	let coinIdent = document.getElementById("coinlinha1") //chamar os elementos html por id
	let coinInfo = document.getElementById("infolinha1")
	let coinInfoC = document.getElementById("infocoluna1")
	let coinInfoC2 = document.getElementById("infocoluna2")
	//let lP = document.getElementById("linhaPercent")
	

	

	let name = document.createElement("div") //criar elementos html
	let img = document.createElement("img")
	let ranking = document.createElement("div")
	let currentprice = document.createElement("div")
	let max24 = document.createElement("div")
	let min24 = document.createElement("div")

	ranking.id = "Cranking"  //atribuir id aos elementos criados
	currentprice.id = "CpreçoAtual"
	name.id = "Cnome"
	img.id = "Cimagem"
	max24.id = "cMaxMin"
	min24.id = "cMaxMin" 

	ranking.innerHTML = coinData[DetailsI].market_cap_rank + "#" //atribuir valores aos elemtos criados
	img.src = coinData[DetailsI].image
    name.innerHTML = coinData[DetailsI].name
	currentprice.innerHTML = coinData[DetailsI].current_price + "$"
	max24.innerHTML = coinData[DetailsI].high_24h + "$"
	min24.innerHTML = coinData[DetailsI].low_24h + "$"
	
	coinIdent.appendChild(ranking) //atribuir a sua localização através de quem são subelementos
	coinIdent.appendChild(img)
	coinIdent.appendChild(name)
	coinInfo.appendChild(currentprice)
	coinInfoC.appendChild(min24)
	coinInfoC2.appendChild(max24)
	
}

function mudaren(){ //mudar linguagem para ingles
	var favoritosTxt = document.getElementById("details") //chamar os elementos html por id
	var preçotxt = document.getElementById("tpreço")
	var selctlng = document.getElementById("selectedLang")

	favoritosTxt.innerHTML = "Favorites" //atribuição de valores
	preçotxt.innerHTML = "price"
	selctlng.innerHTML = "EN"
	selctlng.backgroundImage.src = "us.svg"
}

function mudares(){ //mudar linguagem para espanhol
	var favoritosTxt = document.getElementById("details") //chamar os elementos html por id
	var preçotxt = document.getElementById("tpreço")
	var selctlng = document.getElementById("selectedLang")

	favoritosTxt.innerHTML = "Favoritos" //atribuição de valores
	preçotxt.innerHTML = "precio"
	selctlng.innerHTML = "ES"
}

function mudarpt(){ //mudar linguagem para português 
	var favoritosTxt = document.getElementById("details") //chamar os elementos html por id
	var preçotxt = document.getElementById("tpreço")
	var selctlng = document.getElementById("selectedLang")

	favoritosTxt.innerHTML = "Favoritos" //atribuição de valores
	preçotxt.innerHTML = "preço"
	selctlng.innerHTML = "PT"
	
}

function mudarfr(){ //mudar linguagem para francês
	var favoritosTxt = document.getElementById("details") //chamar os elementos html por id
	var preçotxt = document.getElementById("tpreço")
	var selctlng = document.getElementById("selectedLang")

	favoritosTxt.innerHTML = "Favoris" //atribuição de valores
	preçotxt.innerHTML = "le prix"
	selctlng.innerHTML = "FR"
	
}
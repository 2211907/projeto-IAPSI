'use strict'
var inverterLuz = 0
function mudarLuz(){

    var i
    var x
    var y
    var z
    var t
    var header = document.getElementById("Header") //chamar elementos html através do seu id
    var favoritosTxt = document.getElementById("btnfavoritos")
    var content = document.getElementById("content")
    var search = document.getElementById("search")
    var vline = document.getElementById("Vline")
    var selectedlang = document.getElementById("selectedLang")
    var tdcontent = document.getElementsByClassName("tdcontent")
    var logoimg = document.getElementById("logoimg")
    var lightmode = document.getElementById("lightMode")


    if(inverterLuz==0) // light mode
    {
        x=1
        y=0
        header.setAttribute("style", "background-color: #FAFAFA")
        favoritosTxt.setAttribute("style", "color:black;")
        content.setAttribute("style","background-color: #FAFAFA")
        search.setAttribute("style","background: #FAFAFA; color: black")
        vline.setAttribute("style", "background-color: black")
        selectedlang.setAttribute("style", "color: black;")
        logoimg.src = "black-logo.png"
        lightmode.setAttribute("style", "color: #1a1c1d")
        for(i=0; i<tdcontent.length; i++)
        {
            
            tdcontent[i].style.color = "#1a1c1d"
            tdcontent[i].style.backgroundColor = "#f0f0f0"
            tdcontent[i].style.boxShadow = "1px 3px #dbdbdb"
            if(x == 7){
                
                x=1
                y++
                
                
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#FAFAFA"
                tdcontent[i].style.boxShadow = "1px 3px #e6e6e6"
                
            }
            x++
            
            
        }
        inverterLuz = 1;
    }
    else //dark mode
    {
        x=1
        y=0
        header.setAttribute("style", "background-color: #1a1c1d")
        favoritosTxt.setAttribute("style", "color:white;")
        content.setAttribute("style","background-color: #1a1c1d")
        search.setAttribute("style","background: #1a1c1d; color: #ffffff")
        vline.setAttribute("style", "background-color: white")
        selectedlang.setAttribute("style", "color: white;")
        logoimg.src = "white logo.png"
        lightmode.setAttribute("style", "color: #FAFAFA")
        for(i=0; i<tdcontent.length; i++) 
        {
            
            tdcontent[i].style.color = "#FAFAFA"
            tdcontent[i].style.backgroundColor = "#1a1c1d"
            tdcontent[i].style.boxShadow = "1px 3px #070808"
            if(x == 7){
                
                x=1
                y++
                
                
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#111213"
                tdcontent[i].style.boxShadow = "1px 3px #000000"
                
            }
            x++
            
            
        }
        inverterLuz = 0; 
    }
    
}

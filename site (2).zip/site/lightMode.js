'use strict'
var inverterLuz = 0
function mudarLuz(){

    var header = document.getElementById("Header")
    var details = document.getElementById("details")
    var content = document.getElementById("content")
    var search = document.getElementById("search")
    var vline = document.getElementById("Vline")
    var selectedlang = document.getElementById("selectedLang")
    var langmenu = document.getElementById("langMenu")


    if(inverterLuz==0)
    {
         header.setAttribute("style", "background-color: #ededed")
         details.setAttribute("style", "color:black;")
         content.setAttribute("style","background-color: #ededed")
         search.setAttribute("style","background: #ededed; color: black")
         vline.setAttribute("style", "background-color: black")
         selectedlang.setAttribute("style", "color: balck;")
         inverterLuz = 1;
    }
    else
    {
        header.setAttribute("style", "background-color: #1a1c1d")
        details.setAttribute("style", "color:white;")
        content.setAttribute("style","background-color: #1a1c1d")
        search.setAttribute("style","background: #1a1c1d; color: #ffffff")
        vline.setAttribute("style", "background-color: white")
        selectedlang.setAttribute("style", "color: white;")
        inverterLuz = 0; 
    }
    
}

'use strict'

var coinData;
var altData;
var i;
var x;
var y;
var color;
var oPreco = [];
var auxiliar = [];
var index;
var verdade;
var inverter = [6];

inverter[0] = 0; //Nome
inverter[1] = 0; //Preço
inverter[2] = 0; //Max 24h
inverter[3] = 0; //Min 24h
inverter[4] = 0; //24h %
inverter[5] = 0; //Valor de mercado

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	maximumFractionDigits: 9,
	mininumFractionDigits: 2,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	maximumFractionDigits: 0,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'EUR',
	maximumFractionDigits: 9,
	mininumFractionDigits: 2,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'EUR',
	maximumFractionDigits: 0,
});


$(document).ready(function(){
	requestCoinGeckoData();
});

function criarLinha(coinData){

	
	const indexTd = document.createElement("td")
	indexTd.classList.add("index")
    let linha = document.createElement("tr")
	//let linha = document.createElement("tr",{"id":"linha"})
	let tdId = document.body.appendChild(indexTd)
    let tdName = document.createElement("td")
    let tdPrice = document.createElement("td")
	let tdMax24 = document.createElement("td")
	let tdMin24 = document.createElement("td")
	let tdper24 = document.createElement("td")
	let tdMrktCap = document.createElement("td")

	linha.id = "linha"
    tdId.innerHTML = i
    tdName.innerHTML = coinData.name
    tdPrice.innerHTML = coinData.current_price + "$"
	tdMax24.innerHTML = coinData.high_24h + "$"
	tdMin24.innerHTML = coinData.low_24h + "$"
	tdper24.innerHTML = coinData.price_change_percentage_24h + "%"
	tdMrktCap.innerHTML = coinData.market_cap + "$"

    
    linha.appendChild(tdId);
    linha.appendChild(tdName);
    linha.appendChild(tdPrice);
	linha.appendChild(tdMax24);
	linha.appendChild(tdMin24);
	linha.appendChild(tdper24);
	linha.appendChild(tdMrktCap);
    

    return linha;

}

function parseCoinData(res){
    i = 1;
	color = 0;
	coinData=res;
	auxiliar = coinData;
    let tabela = document.getElementById("tabela")

	


    coinData.forEach(element => {
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Onome(){

	if(inverter[0] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.name > b.name){
				return 1;
			}
			if (a.name < b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.name < b.name){
				return 1;
			}
			if (a.name > b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 0;
	}
	
    
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}



function Oprice(){
	if(inverter[1] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.current_price > b.current_price){
				return 1;
			}
			if (a.current_price < b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.current_price < b.current_price){
				return 1;
			}
			if (a.current_price > b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 0;
	}
    
	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omax24(){
	if(inverter[2] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.high_24h > b.high_24h){
				return 1;
			}
			if (a.high_24h < b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.high_24h < b.high_24h){
				return 1;
			}
			if (a.high_24h > b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omin24(){
	if(inverter[3] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.low_24h > b.low_24h){
				return 1;
			}
			if (a.low_24h < b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.low_24h < b.low_24h){
				return 1;
			}
			if (a.low_24h > b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Oper24(){
	if(inverter[4] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omrktcap(){
	
    if(inverter[5] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.market_cap > b.market_cap){
				return 1;
			}
			if (a.market_cap < b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.market_cap < b.market_cap){
				return 1;
			}
			if (a.market_cap > b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 0;
	}
    
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function requestCoinGeckoData(){
	$.ajax({
		url: 'https://api.coingecko.com/api/v3/coins/markets?per_page=100&vs_currency=usd',
		headers:{
			'Content-Type': 'application/json',
		},
		method: 'GET',
		dataType: 'json',
		data: '',
		success: function(res){
			parseCoinData(res);
		}
	});
}
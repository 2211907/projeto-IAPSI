'use strict'

var coinData;
var altData;
var i;
var x;
var y;
var color;
var oPreco = [];
var auxiliar = [];
var index;
var verdade;
var inverter = [6];
var Home = document.getElementById("pagina1");
var Detalhes = document.getElementById("paginaDetalhes")
var DetailsI

inverter[0] = 0; //Nome
inverter[1] = 0; //Preço
inverter[2] = 0; //Max 24h
inverter[3] = 0; //Min 24h
inverter[4] = 0; //24h %
inverter[5] = 0; //Valor de mercado
 /*
var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	maximumFractionDigits: 9,
	mininumFractionDigits: 2,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	maximumFractionDigits: 0,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'EUR',
	maximumFractionDigits: 9,
	mininumFractionDigits: 2,
});

var priceFormatter = new Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'EUR',
	maximumFractionDigits: 0,
});
*/

$(document).ready(function(){
	requestCoinGeckoData();
	
});

function CorInicial(){

	var i
    var x
    var y
    var z
    var t
    var header = document.getElementById("Header")
    var details = document.getElementById("details")
    var content = document.getElementById("content")
    var search = document.getElementById("search")
    var vline = document.getElementById("Vline")
    var selectedlang = document.getElementById("selectedLang")
   // var langmenu = document.getElementById("langMenu")
    var tdcontent = document.getElementsByClassName("tdcontent")
	x=1
        y=0
        header.setAttribute("style", "background-color: #1a1c1d")
        details.setAttribute("style", "color:white;")
        content.setAttribute("style","background-color: #1a1c1d")
        search.setAttribute("style","background: #1a1c1d; color: #ffffff")
        vline.setAttribute("style", "background-color: white")
        selectedlang.setAttribute("style", "color: white;")
        for(i=0; i<tdcontent.length; i++)
        {
            
            tdcontent[i].style.color = "#FAFAFA"
            tdcontent[i].style.backgroundColor = "#1a1c1d"
            tdcontent[i].style.boxShadow = "1px 3px #070808"
            if(x == 7){
                
                x=1
                y++
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#111213"
                tdcontent[i].style.boxShadow = "1px 3px #000000"
                
            }
            x++
            
            
        }

}

function criarLinha(coinData){

	
	const indexTd = document.createElement("td")
	/*const nameTd = document.createElement("td")
	const priceTd = document.createElement("td")
	const max24Td = document.createElement("td")
	const min24Td = document.createElement("td")
	const per24Td = document.createElement("td")
	const mrktcapTd = document.createElement("td")
*/
	indexTd.classList.add("indextd")/*
	nameTd.classList.add("nametd")
	priceTd.classList.add("pricetd")
	max24Td.classList.add("max24td")
	min24Td.classList.add("min24td")
	per24Td.classList.add("per24td")
	mrktcapTd.classList.add("mrktcaptd")
*/
    let linha = document.createElement("tr")
	//let linha = document.createElement("tr",{"id":"linha"})
	let tdId = document.body.appendChild(indexTd)
    let tdName = document.createElement("td")
    let tdPrice = document.createElement("td")
	let tdMax24 = document.createElement("td")
	let tdMin24 = document.createElement("td")
	let tdper24 = document.createElement("td")
	let tdMrktCap = document.createElement("td")

	linha.id = "linha"
	tdName.className = "tdcontent"
	tdPrice.className = "tdcontent"
	tdMax24.className = "tdcontent"
	tdMin24.className = "tdcontent"
	tdper24.className = "tdcontent"
	tdMrktCap.className = "tdcontent"

    tdId.innerHTML = i
    tdName.innerHTML = coinData.name
    tdPrice.innerHTML = coinData.current_price + "$"
	tdMax24.innerHTML = coinData.high_24h + "$"
	tdMin24.innerHTML = coinData.low_24h + "$"
	tdper24.innerHTML = coinData.price_change_percentage_24h + "%"
	tdMrktCap.innerHTML = coinData.market_cap + "$"

    
    linha.appendChild(tdId);
    linha.appendChild(tdName);
    linha.appendChild(tdPrice);
	linha.appendChild(tdMax24);
	linha.appendChild(tdMin24);
	linha.appendChild(tdper24);
	linha.appendChild(tdMrktCap);
    

    return linha;

}

function parseCoinData(res){
    i = 1;
	//color = 0;
	coinData=res;
	auxiliar = coinData;
    let tabela = document.getElementById("tabela")

	


    coinData.forEach(element => {
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		
    });
	CorInicial() 
	
}

function Onome(){

	if(inverter[0] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.name > b.name){
				return 1;
			}
			if (a.name < b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.name < b.name){
				return 1;
			}
			if (a.name > b.name){
				return -1;
			}
			return 0;
		})
		inverter[0] = 0;
	}
	
    
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}



function Oprice(){
	if(inverter[1] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.current_price > b.current_price){
				return 1;
			}
			if (a.current_price < b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.current_price < b.current_price){
				return 1;
			}
			if (a.current_price > b.current_price){
				return -1;
			}
			return 0;
		})
		inverter[1] = 0;
	}
    
	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omax24(){
	if(inverter[2] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.high_24h > b.high_24h){
				return 1;
			}
			if (a.high_24h < b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.high_24h < b.high_24h){
				return 1;
			}
			if (a.high_24h > b.high_24h){
				return -1;
			}
			return 0;
		})
		inverter[2] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omin24(){
	if(inverter[3] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.low_24h > b.low_24h){
				return 1;
			}
			if (a.low_24h < b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.low_24h < b.low_24h){
				return 1;
			}
			if (a.low_24h > b.low_24h){
				return -1;
			}
			return 0;
		})
		inverter[3] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		
		var btnCP = coinData[0].current_price
    }); 
}

function Oper24(){
	if(inverter[4] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.price_change_percentage_24h < b.price_change_percentage_24h){
				return 1;
			}
			if (a.price_change_percentage_24h > b.price_change_percentage_24h){
				return -1;
			}
			return 0;
		})
		inverter[4] = 0;
	}

	//const alltd = document.getElementsByTagName("tr");
	//$("#tabela tr").empty();
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function Omrktcap(){
	
    if(inverter[5] == 0)
	{
		coinData.sort(function (a, b) {
			if (a.market_cap > b.market_cap){
				return 1;
			}
			if (a.market_cap < b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 1;
	}
	else{
		coinData.sort(function (a, b) {
			if (a.market_cap < b.market_cap){
				return 1;
			}
			if (a.market_cap > b.market_cap){
				return -1;
			}
			return 0;
		})
		inverter[5] = 0;
	}
    
	i=1;
    coinData.forEach(element => {
		$("#linha").remove();
        let linha = criarLinha(element)
        tabela.appendChild(linha)
        i = i+1;
		

    }); 
}

function requestCoinGeckoData(){
	$.ajax({
		url: 'https://api.coingecko.com/api/v3/coins/markets?per_page=100&vs_currency=usd',
		headers:{
			'Content-Type': 'application/json',
		},
		method: 'GET',
		dataType: 'json',
		data: '',
		success: function(res){
			parseCoinData(res);
		}
	});
}

function identify(){
	var cnt;
	for(cnt=0;cnt < 100; cnt++ )
	{
		
	}
}

function OpenDetails(){
	var z
	var x = document.getElementById("searchTxt").value;

	for(z=0 ; z<100; z++)
	{
		if (x === coinData[z].name){
			//window.open("/details.html");
			//location.href = "datails.html";
			console.log(coinData[z].name)
		    DetailsI = z;
			Home.setAttribute("style","display: none")
			paginaDetalhes()
			
		}
		else{
			//console.log("não existe")
		}
	}

	
	
}

function homeReturn(){
	Home.setAttribute("style","display: block")
	Detalhes.setAttribute("style","display: none")
}

function paginaDetalhes(){
	Detalhes.setAttribute("style","display: block")
	location.href = "#";

	$("#Cranking").remove();
	$("#preçoAtual").remove();
	$("#Cnome").remove();
	$("#Cimagem").remove();
	$("#CpreçoAtual").remove();
	let coinIdent = document.getElementById("coinlinha1")
	let coinInfo = document.getElementById("infolinha1")

	

	let name = document.createElement("div")
	let img = document.createElement("img")
	let ranking = document.createElement("div")
	let currentprice = document.createElement("div")

	ranking.id = "Cranking"
	currentprice.id = "CpreçoAtual"
	name.id = "Cnome"
	img.id = "Cimagem"

	ranking.innerHTML = coinData[DetailsI].market_cap_rank
	img.src = coinData[DetailsI].image
    name.innerHTML = coinData[DetailsI].name
	currentprice.innerHTML = "Valor Atual: " + coinData[DetailsI].current_price + "$"

	
	coinIdent.appendChild(ranking)
	coinIdent.appendChild(img)
	coinIdent.appendChild(name)
	coinInfo.appendChild(currentprice)
	
}

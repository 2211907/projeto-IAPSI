'use strict'
var inverterLuz = 0
function mudarLuz(){

    var i
    var x
    var y
    var z
    var t
    var header = document.getElementById("Header")
    var details = document.getElementById("details")
    var content = document.getElementById("content")
    var search = document.getElementById("search")
    var vline = document.getElementById("Vline")
    var selectedlang = document.getElementById("selectedLang")
   // var langmenu = document.getElementById("langMenu")
    var tdcontent = document.getElementsByClassName("tdcontent")


    if(inverterLuz==0)
    {
        x=1
        y=0
        header.setAttribute("style", "background-color: #FAFAFA")
        details.setAttribute("style", "color:black;")
        content.setAttribute("style","background-color: #FAFAFA")
        search.setAttribute("style","background: #FAFAFA; color: black")
        vline.setAttribute("style", "background-color: black")
        selectedlang.setAttribute("style", "color: black;")
        for(i=0; i<tdcontent.length; i++)
        {
            
            tdcontent[i].style.color = "#1a1c1d"
            tdcontent[i].style.backgroundColor = "#f0f0f0"
            tdcontent[i].style.boxShadow = "1px 3px #dbdbdb"
            if(x == 7){
                
                x=1
                y++
                
                
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#FAFAFA"
                tdcontent[i].style.boxShadow = "1px 3px #e6e6e6"
                
            }
            x++
            
            
        }
        inverterLuz = 1;
    }
    else
    {
        x=1
        y=0
        header.setAttribute("style", "background-color: #1a1c1d")
        details.setAttribute("style", "color:white;")
        content.setAttribute("style","background-color: #1a1c1d")
        search.setAttribute("style","background: #1a1c1d; color: #ffffff")
        vline.setAttribute("style", "background-color: white")
        selectedlang.setAttribute("style", "color: white;")
        for(i=0; i<tdcontent.length; i++)
        {
            
            tdcontent[i].style.color = "#FAFAFA"
            tdcontent[i].style.backgroundColor = "#1a1c1d"
            tdcontent[i].style.boxShadow = "1px 3px #070808"
            if(x == 7){
                
                x=1
                y++
                
                
                
            }
            if(y%2 != 0)
            {
                tdcontent[i].style.backgroundColor = "#111213"
                tdcontent[i].style.boxShadow = "1px 3px #000000"
                
            }
            x++
            
            
        }
        inverterLuz = 0; 
    }
    
}

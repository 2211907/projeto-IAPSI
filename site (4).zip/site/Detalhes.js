import DetailsI from './tabela';

console.log(DetailsI)